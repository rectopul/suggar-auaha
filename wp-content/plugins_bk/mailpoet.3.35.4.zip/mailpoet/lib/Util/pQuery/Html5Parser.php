<?php

namespace MailPoet\Util\pQuery;

class Html5Parser extends \pQuery\HtmlParser {
  /** @var string|\pQuery\DomNode */
  public $root = 'MailPoet\Util\pQuery\DomNode';
}
