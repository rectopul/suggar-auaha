<?php

namespace MailPoet\Models;

class Log extends Model {
  public static $_table = MP_LOG_TABLE;

}